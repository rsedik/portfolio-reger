document.addEventListener("DOMContentLoaded", function() {
    const scrollContainer = document.querySelector('#scrollContainer'); // Utiliser #scrollContainer au lieu de .scroll-container
    const selectedImage = document.getElementById('selectedImage');
    const firstImage = scrollContainer.querySelector('img'); // Sélectionne la première image

    firstImage.style.border = '2px solid black'; // Ajoute une bordure noire à la première image
    selectedImage.src = firstImage.src; // Affiche l'image cliquée dans .vuePhoto > .photo

    const images = scrollContainer.querySelectorAll('img');
    images.forEach((img) => {
        img.style.filter = 'grayscale(0%) brightness(80%)'; // Applique le filtre noir et blanc et réduit la luminosité à toutes les images
    });

    scrollContainer.addEventListener('click', (event) => {
        const clickedImage = event.target;

        if (clickedImage.tagName === 'IMG') {
            images.forEach((img) => {
                img.style.border = 'none'; // Retire la bordure noire de toutes les images
                img.style.filter = 'grayscale(0%) brightness(80%)'; // Réapplique le filtre noir et blanc à toutes les images
            });
            clickedImage.style.border = '2px solid black'; // Ajoute une bordure noire à l'image cliquée
            clickedImage.style.filter = 'none'; // Supprime le filtre de l'image cliquée
            selectedImage.src = clickedImage.src; // Affiche l'image cliquée dans .vuePhoto > .photo
        }
    });
});
